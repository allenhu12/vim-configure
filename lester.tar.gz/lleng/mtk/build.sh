#! /bin/bash

IMAGE_NAME=ruckus/mtk_u_1804
sudo docker build -t $IMAGE_NAME ./