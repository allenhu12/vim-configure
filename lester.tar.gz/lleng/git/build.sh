#! /bin/bash

IMAGE_NAME=ruckus/git_u_1404
sudo docker build -t $IMAGE_NAME ./