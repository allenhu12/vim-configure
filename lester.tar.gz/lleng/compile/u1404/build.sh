#! /bin/bash

IMAGE_NAME=ruckus/ap_u_1404
sudo docker build -t $IMAGE_NAME ./