#! /bin/bash

IMAGE_NAME=ruckus/compile_centos_7.7
sudo docker build -t $IMAGE_NAME ./
